console.log('js is working!!');


//fades the page in
$(document).ready(function(){
    $('#customFadeIn').hide().fadeIn(3500);
});

